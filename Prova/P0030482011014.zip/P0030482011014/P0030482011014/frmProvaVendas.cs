﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482011014
{
    public partial class frmProvaVendas : Form
    {
        public frmProvaVendas()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[4,4];
            double total = 0, totalGeral = 0;
            bool aux;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    do
                    {
                        aux = double.TryParse(Interaction.InputBox("Semana " + (j + 1), "Mês " + (i + 1)), out matriz[i,j]);
                    } while (aux == false);
                    total += matriz[i, j];
                    lstVendas.Items.Add("Mês: " + (i + 1) + " Semana: " + (j + 1) + " = " + matriz[i,j].ToString("C2"));
                }
                lstVendas.Items.Add("Total do Mês " + (i + 1) + " = " + total.ToString("C2") + "\n");
                lstVendas.Items.Add("");
                totalGeral += total;
                total = 0;
            }
            lstVendas.Items.Add("Total Geral = " + totalGeral.ToString("C2"));
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstVendas.Items.Clear();
        }
    }
}
